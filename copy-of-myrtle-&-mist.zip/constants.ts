import { Product } from './types';

export const MIST_PRODUCTS: Product[] = [
  {
    id: 1,
    name: "Coastal Pine Candle",
    price: 28,
    image: "https://picsum.photos/id/10/400/500",
    category: "Home Fragrance",
    description: "Notes of sea salt, pine needle, and driftwood."
  },
  {
    id: 2,
    name: "Lavender Mist Linen Spray",
    price: 22,
    image: "https://picsum.photos/id/360/400/500",
    category: "Wellness",
    description: "Organic lavender distillate to calm the mind before sleep."
  },
  {
    id: 3,
    name: "Ceramic Tea Set",
    price: 65,
    image: "https://picsum.photos/id/225/400/500",
    category: "Home Goods",
    description: "Hand-thrown ceramic teapot with two matching cups."
  },
  {
    id: 4,
    name: "Eucalyptus Bath Soak",
    price: 34,
    image: "https://picsum.photos/id/514/400/500",
    category: "Body Care",
    description: "Mineral-rich salts infused with eucalyptus and peppermint."
  },
];

export const MYRTLE_PRODUCTS: Product[] = [
  {
    id: 101,
    name: "Monstera Deliciosa",
    price: 45,
    image: "https://picsum.photos/id/106/400/500",
    category: "Live Plants",
    description: "The classic Swiss Cheese plant. Requires bright, indirect light."
  },
  {
    id: 102,
    name: "Terracotta Pot (10\")",
    price: 18,
    image: "https://picsum.photos/id/112/400/500",
    category: "Planters",
    description: "Breathable clay pot, perfect for aroids and succulents."
  },
  {
    id: 103,
    name: "Brass Misting Spray",
    price: 32,
    image: "https://picsum.photos/id/400/400/500",
    category: "Tools",
    description: "Solid brass mister for humidity-loving tropicals."
  },
  {
    id: 104,
    name: "Fiddle Leaf Fig",
    price: 85,
    image: "https://picsum.photos/id/628/400/500",
    category: "Live Plants",
    description: "Large, sculptural tree. A statement piece for any room."
  },
];

export const NAV_LINKS = [
  { name: 'Shop', href: '#shop' },
  { name: 'About', href: '#about' },
  { name: 'Assistant', href: '#muse' },
];

export const THEME_CONTENT = {
  myrtle: {
    tagline: "Growth • Sunlight • Structure",
    headline: "Bring Life Inside",
    subheadline: "Everything you need to cultivate your own indoor jungle. Scientific plant care meets modern design.",
    cta: "Shop Botanicals",
    heroImage: "https://picsum.photos/id/106/1920/1080", // Bright, plant focused
    aboutHeadline: "Rooted in Science, Grown with Love",
    aboutText: "Myrtle is dedicated to the biology of plants. We provide healthy, acclimated specimens and the precise tools you need to help them thrive.",
    assistantName: "Myrtle Bot",
    assistantRole: "Botanical Specialist"
  },
  mist: {
    tagline: "Silence • Balance • Serenity",
    headline: "Breathe in the Silence",
    subheadline: "Curated essentials for a mindful home and a grounded spirit. Discover the art of slow living.",
    cta: "Explore Collection",
    heroImage: "https://picsum.photos/id/10/1920/1080", // Moody, nature
    aboutHeadline: "Born from the Earth, Crafted for the Soul",
    aboutText: "Mist is a sanctuary for the senses. We source ethical botanicals and materials designed to evoke calm and restore balance.",
    assistantName: "Mist Muse",
    assistantRole: "Wellness Companion"
  }
};