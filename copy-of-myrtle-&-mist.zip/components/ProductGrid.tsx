import React from 'react';
import { MYRTLE_PRODUCTS, MIST_PRODUCTS } from '../constants';
import { useTheme } from './ThemeContext';

const ProductGrid: React.FC = () => {
  const { theme } = useTheme();
  const products = theme === 'myrtle' ? MYRTLE_PRODUCTS : MIST_PRODUCTS;

  return (
    <section id="shop" className={`py-20 theme-transition ${
      theme === 'myrtle' ? 'bg-myrtle-bg' : 'bg-mist-bg'
    }`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className={`text-3xl md:text-4xl mb-4 transition-colors duration-600 ${
            theme === 'myrtle' ? 'font-geo font-bold text-myrtle-text' : 'font-serif text-mist-text'
          }`}>
            {theme === 'myrtle' ? 'The Nursery' : 'Curated Collection'}
          </h2>
          <div className={`w-16 h-0.5 mx-auto transition-colors duration-600 ${
            theme === 'myrtle' ? 'bg-myrtle-accent' : 'bg-mist-accent'
          }`}></div>
          <p className={`mt-4 max-w-2xl mx-auto transition-colors duration-600 ${
            theme === 'myrtle' ? 'text-gray-600' : 'text-gray-400'
          }`}>
            {theme === 'myrtle' ? 'Hardy, acclimatized plants ready for your home.' : 'Handpicked items to bring tranquility to your space.'}
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 md:gap-12">
          {products.map((product) => (
            <div key={product.id} className="group cursor-pointer">
              <div className={`relative aspect-[4/5] overflow-hidden mb-4 transition-colors duration-600 ${
                theme === 'myrtle' ? 'bg-white shadow-sm' : 'bg-mist-secondary'
              }`}>
                <img 
                  src={product.image} 
                  alt={product.name}
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                  loading="lazy"
                />
                <div className="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition-colors duration-300"></div>
                <button className={`absolute bottom-4 left-4 right-4 py-3 uppercase text-xs font-bold tracking-widest opacity-0 transform translate-y-4 transition-all duration-300 group-hover:opacity-100 group-hover:translate-y-0 ${
                  theme === 'myrtle' 
                    ? 'bg-myrtle-accent text-white hover:bg-myrtle-text' 
                    : 'bg-mist-accent text-mist-bg hover:bg-white'
                }`}>
                  Add to Cart
                </button>
              </div>
              <div className="text-center">
                <p className={`text-xs uppercase tracking-wide mb-1 transition-colors duration-600 ${
                  theme === 'myrtle' ? 'text-gray-500 font-bold' : 'text-mist-accent'
                }`}>{product.category}</p>
                <h3 className={`text-lg mb-1 transition-colors duration-600 ${
                  theme === 'myrtle' ? 'font-geo font-bold text-myrtle-text' : 'font-serif text-mist-text'
                }`}>
                  {product.name}
                </h3>
                <p className={`font-medium transition-colors duration-600 ${
                  theme === 'myrtle' ? 'text-myrtle-accent' : 'text-gray-400'
                }`}>${product.price}.00</p>
              </div>
            </div>
          ))}
        </div>
        
        <div className="mt-16 text-center">
          <button className={`border-b pb-1 transition-colors uppercase text-sm tracking-widest ${
            theme === 'myrtle' 
              ? 'text-myrtle-text border-myrtle-text hover:text-myrtle-accent hover:border-myrtle-accent' 
              : 'text-mist-text border-mist-text hover:text-mist-accent hover:border-mist-accent'
          }`}>
            View All Products
          </button>
        </div>
      </div>
    </section>
  );
};

export default ProductGrid;