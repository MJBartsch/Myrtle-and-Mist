import React, { useState, useEffect } from 'react';
import { NAV_LINKS } from '../constants';
import { useTheme } from './ThemeContext';

const Header: React.FC = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const { theme } = useTheme();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Dynamic classes based on theme
  const getHeaderClasses = () => {
    if (!isScrolled) return 'bg-transparent py-6';
    
    return theme === 'myrtle' 
      ? 'bg-myrtle-bg/95 shadow-sm py-4' 
      : 'bg-mist-bg/90 shadow-sm py-4 border-b border-mist-secondary';
  };

  const getLinkClasses = () => {
    const base = "text-sm font-medium tracking-wide uppercase transition-colors duration-300";
    if (!isScrolled) {
        // On transparent hero, assume light text for Mist, dark for Myrtle unless hero changes image dramatically.
        // Actually both hero images are full bleed. Let's make text dynamic to scroll.
        // Or assume hero text is always white-ish for Mist and dark for Myrtle? 
        // Let's rely on scroll state.
        return theme === 'myrtle' ? 'text-myrtle-text/80 hover:text-myrtle-accent' : 'text-mist-text/80 hover:text-mist-accent';
    }
    return theme === 'myrtle' 
      ? 'text-myrtle-text hover:text-myrtle-accent' 
      : 'text-mist-text hover:text-mist-accent';
  };

  const logoFont = theme === 'myrtle' ? 'font-geo font-bold tracking-tight' : 'font-serif font-bold tracking-wider';

  return (
    <header 
      className={`fixed w-full z-40 transition-all duration-600 ${getHeaderClasses()} ${isScrolled ? 'backdrop-blur-md' : ''}`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex justify-between items-center">
        {/* Logo */}
        <div className="flex-shrink-0">
          <a href="#" className={`text-2xl transition-colors duration-600 ${logoFont} ${
            isScrolled 
              ? (theme === 'myrtle' ? 'text-myrtle-text' : 'text-mist-text') 
              : 'text-white' // Always white on hero for visibility? Or dynamic?
            } ${!isScrolled && theme === 'myrtle' ? '!text-myrtle-text' : ''}  
          `}>
            Myrtle & Mist
          </a>
        </div>

        {/* Desktop Nav */}
        <nav className="hidden md:flex space-x-8">
          {NAV_LINKS.map((link) => (
            <a
              key={link.name}
              href={link.href}
              className={`${getLinkClasses()} ${!isScrolled && theme === 'myrtle' ? '!text-myrtle-text/80 hover:!text-myrtle-accent' : ''}`}
            >
              {link.name}
            </a>
          ))}
          <button className={`${getLinkClasses()} ${!isScrolled && theme === 'myrtle' ? '!text-myrtle-text/80 hover:!text-myrtle-accent' : ''}`}>
            Cart (0)
          </button>
        </nav>

        {/* Mobile Menu Button */}
        <div className="md:hidden">
          <button
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className={`focus:outline-none transition-colors duration-300 ${
              isScrolled 
                ? (theme === 'myrtle' ? 'text-myrtle-text' : 'text-mist-text')
                : (theme === 'myrtle' ? 'text-myrtle-text' : 'text-white')
            }`}
          >
            <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              {isMobileMenuOpen ? (
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              ) : (
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
              )}
            </svg>
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {isMobileMenuOpen && (
        <div className={`md:hidden absolute w-full shadow-lg border-t theme-transition ${
          theme === 'myrtle' ? 'bg-myrtle-bg border-myrtle-secondary' : 'bg-mist-bg border-mist-secondary'
        }`}>
          <div className="px-4 pt-2 pb-6 space-y-1">
            {NAV_LINKS.map((link) => (
              <a
                key={link.name}
                href={link.href}
                className={`block px-3 py-2 text-base font-medium rounded-md transition-colors ${
                  theme === 'myrtle' 
                    ? 'text-myrtle-text hover:text-myrtle-accent hover:bg-myrtle-secondary' 
                    : 'text-mist-text hover:text-mist-accent hover:bg-mist-secondary'
                }`}
                onClick={() => setIsMobileMenuOpen(false)}
              >
                {link.name}
              </a>
            ))}
          </div>
        </div>
      )}
    </header>
  );
};

export default Header;