import React from 'react';
import { useTheme } from './ThemeContext';
import { THEME_CONTENT } from '../constants';

const Hero: React.FC = () => {
  const { theme } = useTheme();
  const content = THEME_CONTENT[theme];

  return (
    <div className="relative h-screen min-h-[600px] flex items-center justify-center overflow-hidden theme-transition bg-black">
      {/* Background Image Container */}
      <div className={`absolute inset-0 z-0 transition-opacity duration-1000 ${theme === 'myrtle' ? 'opacity-100' : 'opacity-0'}`}>
         {/* Myrtle Image (High key) */}
        <img 
          src={THEME_CONTENT.myrtle.heroImage} 
          alt="Bright greenhouse" 
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-white/20"></div>
      </div>

      <div className={`absolute inset-0 z-0 transition-opacity duration-1000 ${theme === 'mist' ? 'opacity-100' : 'opacity-0'}`}>
        {/* Mist Image (Low key) */}
        <img 
          src={THEME_CONTENT.mist.heroImage} 
          alt="Misty landscape" 
          className="w-full h-full object-cover grayscale-[30%]"
        />
        <div className="absolute inset-0 bg-mist-bg/40 mix-blend-multiply"></div>
        <div className="absolute inset-0 bg-gradient-to-b from-transparent to-mist-bg"></div>
      </div>

      {/* Content */}
      <div className="relative z-10 text-center px-4 max-w-4xl mx-auto mt-20">
        <span className={`block text-sm md:text-base tracking-[0.3em] uppercase mb-4 animate-fade-in-up font-bold transition-colors duration-600 ${
          theme === 'myrtle' ? 'text-myrtle-accent' : 'text-white/80'
        }`}>
          {content.tagline}
        </span>
        
        <h1 className={`mb-6 drop-shadow-sm transition-all duration-600 ${
          theme === 'myrtle' 
            ? 'font-geo text-5xl md:text-7xl font-extrabold text-myrtle-text tracking-tight' 
            : 'font-serif text-5xl md:text-7xl lg:text-8xl text-white'
        }`}>
          {content.headline === 'Breathe in the Silence' ? (
            <>Breathe in the<br/><span className="italic text-mist-accent">Silence</span></>
          ) : (
            <>Bring <span className="text-myrtle-accent">Life</span> Inside</>
          )}
        </h1>

        <p className={`text-lg md:text-xl mb-10 max-w-2xl mx-auto leading-relaxed transition-colors duration-600 ${
          theme === 'myrtle' ? 'text-myrtle-text font-medium' : 'text-mist-text/90 font-light'
        }`}>
          {content.subheadline}
        </p>

        <a 
          href="#shop"
          className={`inline-block px-8 py-3 rounded-sm font-bold uppercase tracking-widest text-sm transition-all duration-300 hover:shadow-lg transform hover:-translate-y-0.5 ${
            theme === 'myrtle'
              ? 'bg-myrtle-accent text-white hover:bg-myrtle-text'
              : 'bg-mist-accent text-mist-bg hover:bg-white'
          }`}
        >
          {content.cta}
        </a>
      </div>
    </div>
  );
};

export default Hero;