import React from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import ProductGrid from './components/ProductGrid';
import About from './components/About';
import WellnessChat from './components/WellnessChat';
import Footer from './components/Footer';
import { ThemeProvider, useTheme } from './components/ThemeContext';
import ThemeToggle from './components/ThemeToggle';

const AppContent: React.FC = () => {
  const { theme } = useTheme();
  
  return (
    <div className={`min-h-screen flex flex-col transition-colors duration-600 ${
      theme === 'myrtle' ? 'bg-myrtle-bg font-sans' : 'bg-mist-bg font-sans'
    }`}>
      <Header />
      <main className="flex-grow">
        <Hero />
        <About />
        <ProductGrid />
        <WellnessChat />
      </main>
      <Footer />
      <ThemeToggle />
    </div>
  );
};

const App: React.FC = () => {
  return (
    <ThemeProvider>
      <AppContent />
    </ThemeProvider>
  );
};

export default App;